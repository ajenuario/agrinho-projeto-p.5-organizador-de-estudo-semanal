let dias = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex'];
let horarios = ['Manhã', 'Tarde', 'Noite'];
let celulas = [];
let largura = 100;
let altura = 60;
let entradaAtiva = false;
let input;
let celulaSelecionada;

function setup() {
  createCanvas(600, 300);
  textAlign(CENTER, CENTER);
  textSize(12);
  criarCelulas();
  carregarDoLocalStorage();
}

function draw() {
  background(240);
  desenharGrande();
}

function criarCelulas() {
  for (let i = 0; i < horarios.length; i++){
    for (let j = 0; j < dias.length; j++){
      celulas.push({
        x: j * largura + 70,
        y: i * altura + 50,
        texto:'',
        dia: dias [j],
        horario: horarios [i]
      });
    }
  }
}
function desenharGrande() {
  // Cabeçalhos
  fill(0);
  for (let i = 0; i < dias.length; i++)
{
    text(dias[i], i * largura + 70 + largura / 2, 30);
  }
  for (let i = 0; i < horarios.length; i++){
    text(horarios[i], 35, i * altura + 50 + altura / 2);
  }
  
  // Células
  for (let cel of celulas) {
    fill(255);
    stroke(0);
    rect(cel.x, cel.y, largura, altura);
    fill(0);
    text(cel.texto, cel.x + largura / 2, cel.y + altura / 2);
  }
}

function mousePressed() {
  if (entradaAtiva) {
    input.remove();
    entradaAtiva = false;
  }
  
  for (let cel of celulas) {
    if (
     mouseX > cel.x &&
     mouseX < cel.x + largura &&
     mouseY > cel.y &&
     mouseY < cel.y + largura 
    ) {
      criarInput(cel);
      break;
    }
  }
}

function criarInput(celula) {
  input = createInput(celula.texto);
  input.position(celula.x + 5, celula.y + 20);
  input.size(largura - 10, altura - 30);
  input.elt.focus();
  entradaAtiva = true;
  celulaSelecionada = celula;
  
  input.input(() => {
    celulaSelecionada.texto = input.value();
    salvarNoLocalStorge();
  });
}

function salvarNoLocalStorge() {
  let dados = JSON.stringify(celulas.map(c => c.texto));
  localStorage.setItem('horariosEstudo', dados);
}

function carregarDoLocalStorage() {
  let dados = localStorage.getItem('horariosEstudo');
  if (dados) {
    let textos = JSON.parse(dados);
    for (let i = 0; i < textos.length; i++){
      celulas[i].texto = textos[i];
    }
  }
}